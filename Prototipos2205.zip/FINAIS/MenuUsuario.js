  //modulos
var http = require('http');
var qs = require('querystring');

// definicoes
var pageHTML = '<html>' +
'<header>' +
 '  <img alt="">' +
  ' <h1>User Menu</h1>' +
 '  </form>' +
'</header>' +
'</head>' +
'<body>' +
'<body background="http://www.androidguys.com/wp-content/uploads/2016/05/WP_Encrusted_VI-2560x1440_00000.jpg">' +
'<form method="post" action="">' +
'<div>'+
'<div>' +
'<label for="fxx">Menu of old resolutions  </label> <p/>' +
'<input type="submit" value="Access" onClick="Page()">' +
'<div>' +
'<label for="fyy">Geometry calculations page  </label> <p/>' +
'<input type="submit" value="Triangle" onClick="Page()">' +
'<input type="submit" value="Circle" onClick="Page()">' +
'<input type="submit" value="Square" onClick="Page()">' +
'<div>' +
'<label for="fxc">Exit Application  </label> <p/>' +
'<input type="submit" value="Exit" onClick="Page()"> '+
'<div>' +
'<body>' +
'<script type="text/javascript">' +
function Page()
{
//location.href="index.html"
window.open("pagina.html","https://www.google.com.br/",windowFeatures); 
}
'</script>' +
'<input type="submit" value="Exit" onClick="Nova()"> '+
'<form >' +
'</form>' +
'</body>' +
'</html>';
// server e acao apos clique de botao

var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
  var requestData = '';
 
  // check HTTP method and show the right content
  if (req.method === "GET") {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(pageHTML); // serve our HTML code
  } else if (req.method === "POST") {
    req.setEncoding('utf-8');
/*
    req.on('data', function(data) {
      requestData += data;
    });
*/ 
   req.on('end', function() {
      var postData = qs.parse(requestData);
  res.writeHead(200, {'Content-Type': 'text/html'});

      res.end('<h1>User creation was been success!!!' + '</h1>');
    });
  }
});

/*funcao
function calcula(form) {
var area = (form.Base.value * form.Altura.value);
form.resultado.value = area;
}
*/

 // habilitando listener
server.listen(1302, '127.0.0.1');
console.log('Server running at http://127.0.0.1:1302/');
